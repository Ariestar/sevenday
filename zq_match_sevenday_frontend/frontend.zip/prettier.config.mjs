import config from '@zqstudio/configs/prettier';
export default config;
