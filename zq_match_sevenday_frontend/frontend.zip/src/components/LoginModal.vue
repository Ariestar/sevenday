<template>
  <view v-if="visible" class="login-modal-overlay" @tap="handleOverlayTap">
    <view class="login-modal-content" @tap.stop>
      <!-- 登录卡片 -->
      <view class="login-card">
        <!-- 王冠插图背景 - 占满整个modal -->
        <view class="crown-background">
          <image 
            src="/static/illustrations/login-card.png" 
            class="crown-image" 
            mode="aspectFit"
          />
          <!-- 透明度遮罩层 -->
          <view class="background-overlay"></view>
        </view>
        
        <!-- 表单内容 - 独立层级 -->
        <view class="form-content" @tap.stop>
          <!-- 邮箱输入 -->
          <view class="form-row">
            <text class="form-label">邮箱</text>
            <view class="input-wrapper" @tap.stop>
              <input 
                v-model="formData.email"
                class="form-input"
                type="text"
                placeholder="请输入"
                placeholder-class="input-placeholder"
                :focus="false"
                :disabled="false"
              />
            </view>
          </view>
          
          <!-- 验证码输入 -->
          <view class="form-row">
            <text class="form-label">验证码</text>
            <view class="verify-code-row">
              <view class="input-wrapper" @tap.stop>
                <input 
                  v-model="formData.verifyCode"
                  class="form-input verify-input"
                  type="text"
                  maxlength="6"
                  placeholder="请输入6位验证码"
                  placeholder-class="input-placeholder"
                  @input="handleVerifyCodeInput"
                  :focus="false"
                  :disabled="false"
                />
              </view>
              <button 
                class="get-code-btn"
                :class="{ disabled: codeCountdown > 0 }"
                :disabled="codeCountdown > 0 || !formData.email"
                @tap.stop="handleGetCode"
              >
                {{ codeCountdown > 0 ? `${codeCountdown}s` : '获取验证码' }}
              </button>
            </view>
          </view>
          
          <!-- 隐私政策 -->
          <view class="privacy-row">
            <view class="checkbox-wrapper" @tap="togglePrivacyAgreement">
              <view class="checkbox" :class="{ checked: privacyAgreed }">
                <text v-if="privacyAgreed" class="check-icon">✓</text>
              </view>
            </view>
            <text class="privacy-text">
              我已阅读并同意<text class="privacy-link" @tap="showPrivacyPolicy">《隐私政策》</text>
            </text>
          </view>
          
          <!-- 登录按钮 -->
          <button 
            class="login-btn"
            :class="{ disabled: !canLogin }"
            :disabled="!canLogin"
            @tap="handleLogin"
          >
            {{ loading ? '登录中...' : '登录' }}
          </button>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import { sendVerifyCode, verifyEmail } from '../services/auth'
import authUtils from '../utils/auth'

export default {
  name: 'LoginModal',
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      formData: {
        email: '',
        verifyCode: ''
      },
      privacyAgreed: false,
      codeCountdown: 0,
      loading: false
    }
  },
  computed: {
    canLogin() {
      return this.formData.email && 
             this.formData.verifyCode && 
             this.privacyAgreed &&
             !this.loading
    }
  },
  methods: {
    handleOverlayTap() {
      this.$emit('close')
    },
    
    togglePrivacyAgreement() {
      this.privacyAgreed = !this.privacyAgreed
    },
    
    showPrivacyPolicy() {
      // 跳转到隐私政策页面
      uni.navigateTo({
        url: '/pages/policy/privacy'
      })
    },
    
    validateEmail(email) {
      // 验证邮箱格式：必须是13位+@whu.edu.cn
      if (!email || !email.trim()) {
        return { valid: false, message: '请输入邮箱' }
      }
      
      const trimmedEmail = email.trim()
      
      // 检查是否以@whu.edu.cn结尾
      if (!trimmedEmail.endsWith('@whu.edu.cn')) {
        return { valid: false, message: '邮箱必须以@whu.edu.cn结尾' }
      }
      
      // 提取@符号前的部分
      const localPart = trimmedEmail.split('@')[0]
      if (localPart.length !== 13) {
        return { valid: false, message: '邮箱前缀必须是13位字符' }
      }
      
      return { valid: true, message: '' }
    },
    
    async handleGetCode() {
      if (this.codeCountdown > 0 || !this.formData.email) {
        return
      }
      
      // 验证邮箱格式
      const emailValidation = this.validateEmail(this.formData.email)
      if (!emailValidation.valid) {
        uni.showToast({
          title: emailValidation.message,
          icon: 'none',
          duration: 2000
        })
        return
      }
      
      try {
        await sendVerifyCode(this.formData.email.trim())
        uni.showToast({
          title: '验证码已发送',
          icon: 'success'
        })
        
        // 开始倒计时
        this.startCountdown()
      } catch (err) {
        console.error('发送验证码失败:', err)
        
        // 提取错误信息并显示给用户
        let errorMessage = '发送验证码失败，请稍后重试'
        
        if (err && err.message) {
          errorMessage = err.message
        } else if (err && typeof err === 'string') {
          errorMessage = err
        } else if (err && err.errMsg) {
          errorMessage = err.errMsg
        }
        
        // 特殊处理邮箱相关错误
        if (errorMessage.includes('邮箱') || errorMessage.includes('13位')) {
          errorMessage = errorMessage.includes('13位') ? '邮箱前缀必须是13位字符' : '邮箱格式不正确'
        }
        
        // 如果是网络错误，给出更明确的提示
        if (errorMessage.includes('invalid url') || errorMessage.includes('600009') || errorMessage.includes('fail')) {
          errorMessage = '网络连接失败，请检查网络设置'
        }
        
        uni.showToast({
          title: errorMessage,
          icon: 'none',
          duration: 3000
        })
      }
    },
    
    startCountdown() {
      this.codeCountdown = 60
      const timer = setInterval(() => {
        this.codeCountdown--
        if (this.codeCountdown <= 0) {
          clearInterval(timer)
        }
      }, 1000)
    },
    
    handleVerifyCodeInput(e) {
      // 只允许输入数字，限制6位
      let value = e.detail.value.replace(/\D/g, '').slice(0, 6)
      this.formData.verifyCode = value
    },
    
    async handleLogin() {
      if (!this.canLogin) {
        return
      }
      
      // 验证邮箱格式
      const emailValidation = this.validateEmail(this.formData.email)
      if (!emailValidation.valid) {
        uni.showToast({
          title: emailValidation.message,
          icon: 'none',
          duration: 2000
        })
        return
      }
      
      // 验证验证码格式
      if (!this.formData.verifyCode || this.formData.verifyCode.length !== 6) {
        uni.showToast({
          title: '请输入6位验证码',
          icon: 'none',
          duration: 2000
        })
        return
      }
      
      // 验证验证码是否为数字
      if (!/^\d{6}$/.test(this.formData.verifyCode)) {
        uni.showToast({
          title: '验证码必须为6位数字',
          icon: 'none',
          duration: 2000
        })
        return
      }
      
      this.loading = true
      try {
        // 确保验证码是字符串类型且长度为6
        const code = String(this.formData.verifyCode).trim()
        if (code.length !== 6) {
          uni.showToast({
            title: '请输入6位验证码',
            icon: 'none',
            duration: 2000
          })
          this.loading = false
          return
        }
        
        console.log('发送验证请求:', {
          email: this.formData.email.trim(),
          code: code,
          codeType: typeof code,
          codeLength: code.length
        })
        const result = await verifyEmail(this.formData.email.trim(), code)
        
        console.log('登录接口返回结果:', result)
        
        // 检查返回结果格式
        if (!result) {
          uni.showToast({
            title: '登录失败：服务器未返回数据',
            icon: 'none',
            duration: 3000
          })
          return
        }
        
        // 兼容不同的后端返回格式
        // 可能是 { token, userInfo } 或 { access_token, user } 等
        const token = result.token || result.access_token || result.accessToken
        const userInfo = result.userInfo || result.user || result.data
        
        if (!token) {
          console.error('登录失败：未找到 token', result)
          uni.showToast({
            title: '登录失败：未获取到认证令牌',
            icon: 'none',
            duration: 3000
          })
          return
        }
        
        if (!userInfo) {
          console.error('登录失败：未找到用户信息', result)
          uni.showToast({
            title: '登录失败：未获取到用户信息',
            icon: 'none',
            duration: 3000
          })
          return
        }
        
        // 使用认证工具保存认证信息
        authUtils.login(token, userInfo)
        
        console.log('登录成功，已保存认证信息')
        
        uni.showToast({
          title: '登录成功',
          icon: 'success'
        })
        
        // 通知父组件登录成功
        this.$emit('login-success', result.userInfo)
        this.$emit('close')
        
        // 重置表单
        this.resetForm()
      } catch (err) {
        console.error('登录失败:', err)
        
        // 提取错误信息并显示给用户
        let errorMessage = '登录失败，请稍后重试'
        
        if (err && err.message) {
          errorMessage = err.message
        } else if (err && typeof err === 'string') {
          errorMessage = err
        } else if (err && err.errMsg) {
          errorMessage = err.errMsg
        }
        
        // 如果是网络错误，给出更明确的提示
        if (errorMessage.includes('invalid url') || errorMessage.includes('600009') || errorMessage.includes('fail')) {
          errorMessage = '网络连接失败，请检查网络设置'
        }
        
        uni.showToast({
          title: errorMessage,
          icon: 'none',
          duration: 3000
        })
      } finally {
        this.loading = false
      }
    },
    
    resetForm() {
      this.formData = {
        email: '',
        verifyCode: ''
      }
      this.privacyAgreed = false
      this.codeCountdown = 0
      this.loading = false
    }
  },
  watch: {
    visible(newVal) {
      if (!newVal) {
        // 弹窗关闭时重置表单
        this.resetForm()
      }
    }
  }
}
</script>

<style scoped>
.login-modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
}

.login-modal-content {
  width: 600rpx;
  height: 840rpx; /* 增加高度，对应420px */
  overflow: hidden;
}

.login-card {
  background-color: #ffffff;
  border-radius: 18rpx;
  overflow: hidden;
  position: relative;
  height: 100%; /* 占满容器高度 */
}

.crown-background {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
  overflow: hidden;
  pointer-events: none; /* 允许点击事件穿透 */
}

.crown-image {
  width: 102%; /* 85% of 120% */
  height: 102%; /* 85% of 120% */
  object-fit: cover;
  position: absolute;
  top: -80rpx; /* 往上移动 */
  left: -10rpx; /* 居中对齐 */
  opacity: 0.7; /* 70%透明度 */
  pointer-events: none; /* 图片不阻挡点击 */
}

.background-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(180deg, rgba(255, 255, 255, 0.3) 0%, rgba(255, 255, 255, 0.6) 19.71%, rgba(255, 255, 255, 0.87) 41.83%, rgba(255, 255, 255, 1) 100%);
  z-index: 2; /* 在背景图片之上，但在表单内容之下 */
  pointer-events: none; /* 允许点击事件穿透到下层元素 */
}

.form-content {
  position: absolute;
  bottom: 10%; /* 向上移动10% */
  left: 0;
  right: 0;
  height: 38%; /* 稍微增加高度以容纳所有内容 */
  padding: 15rpx 32rpx 15rpx; /* 减少padding以更好利用空间 */
  z-index: 100; /* 大幅提高层级，确保在所有背景层之上 */
  display: flex;
  flex-direction: column;
  justify-content: flex-start; /* 从顶部开始排列 */
  overflow-y: auto; /* 如果内容过多可以滚动 */
  background: transparent; /* 确保背景透明，不阻挡下层显示 */
}

.form-row {
  display: flex;
  align-items: center;
  margin-bottom: 16rpx; /* 进一步减少间距 */
  gap: 16rpx;
  position: relative;
  z-index: 101; /* 确保在背景层之上 */
}

.form-label {
  font-size: 32rpx;
  color: #1f2635;
  width: 120rpx; /* 固定标签宽度 */
  flex-shrink: 0;
  text-align: left;
}

.input-wrapper {
  flex: 1;
  position: relative;
  z-index: 102;
  min-width: 0;
}

.form-input {
  width: 100%;
  height: 64rpx;
  background-color: #ffffff;
  border: 2rpx solid #1f2635;
  border-radius: 90rpx;
  padding: 0 30rpx;
  font-size: 28rpx;
  color: #1f2635;
  box-sizing: border-box;
  min-width: 0;
}

.input-placeholder {
  color: #9094a6;
}

.verify-code-row {
  display: flex;
  align-items: center;
  gap: 16rpx;
  flex: 1;
  min-width: 0;
  position: relative;
  z-index: 101; /* 确保在背景层之上 */
}

.verify-input {
  width: 100%;
}

.get-code-btn {
  width: 180rpx; /* 减小宽度以适应新布局 */
  height: 64rpx;
  background-color: #1f2635;
  color: #ffffff;
  font-size: 26rpx; /* 稍微减小字体 */
  border-radius: 90rpx;
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  white-space: nowrap;
}

.get-code-btn.disabled {
  background-color: #ccc;
  color: #666;
}

.privacy-row {
  display: flex;
  align-items: center;
  margin-bottom: 20rpx; /* 减少间距 */
  padding: 0 10rpx;
}

.checkbox-wrapper {
  margin-right: 16rpx;
}

.checkbox {
  width: 28rpx;
  height: 28rpx;
  border: 2rpx solid #ccc;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #ffffff;
}

.checkbox.checked {
  border-color: #667eea;
  background-color: #667eea;
}

.check-icon {
  color: #ffffff;
  font-size: 18rpx;
  font-weight: bold;
}

.privacy-text {
  font-size: 28rpx;
  color: #b3b3b3;
  line-height: 1.4;
}

.privacy-link {
  color: #00bfff;
  text-decoration: underline;
}

.login-btn {
  width: 260rpx; /* 稍微减小宽度 */
  height: 80rpx; /* 稍微减小高度 */
  background-color: #1f2635;
  color: #ffffff;
  font-size: 30rpx; /* 稍微减小字体 */
  border-radius: 90rpx;
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto;
}

.login-btn.disabled {
  background-color: #ccc;
  color: #666;
}
</style>
