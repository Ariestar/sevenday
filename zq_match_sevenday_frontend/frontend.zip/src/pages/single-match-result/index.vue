<template>
  <view class="single-match-result-page">
    <!-- 背景图片 -->
    <view class="result-gradient-bg"></view>

    <!-- 报名/匹配标签切换区域 -->
    <view class="tab-section">
      <view class="tab-group">
        <view class="tab-item" @click="goToSignup">
          <text class="tab-text">报名</text>
        </view>
        <view class="tab-item active">
          <text class="tab-text active">匹配</text>
          <view class="tab-indicator"></view>
        </view>
      </view>
    </view>

    <!-- 标签切换区域 -->
    <view class="result-tab-section">
      <view class="result-tab-group">
        <view class="result-tab-item" @click="backToExpectation">
          <text class="result-tab-text">你的期望</text>
        </view>
        <view class="result-tab-item active">
          <text class="result-tab-text active">智能匹配</text>
          <view class="result-tab-indicator"></view>
        </view>
        <view class="result-tab-item disabled">
          <text class="result-tab-text">确认组队</text>
        </view>
      </view>
    </view>

    <!-- 匹配结果卡片 -->
    <view class="match-result-card">
      <!-- 队友信息区域 -->
      <view class="teammate-info">
        <view class="info-item">
          <text class="info-label">姓名：</text>
          <text class="info-value">{{ matchResult.name}}</text>
        </view>
        <view class="info-item">
          <text class="info-label">性别：</text>
          <text class="info-value">{{ matchResult.gender}}</text>
        </view>
        <view class="info-item">
          <text class="info-label">学历：</text>
          <text class="info-value">{{ matchResult.education}}</text>
        </view>
        <view class="info-item">
          <text class="info-label">大类：</text>
          <text class="info-value">{{ matchResult.majorCategory}}</text>
        </view>
        <view class="info-item">
          <text class="info-label">院系：</text>
          <text class="info-value">{{ matchResult.college  }}</text>
        </view>
      </view>
    </view>

    <!-- 头像区域 -->
    <view class="avatar-section">
      <view class="avatar-circle">
        <image 
          v-if="matchResult.avatar" 
          :src="matchResult.avatar" 
          class="avatar-image" 
          mode="aspectFill"
          @error="handleAvatarError"
        />
        <text v-else class="avatar-placeholder">👤</text>
      </view>
    </view>

    <!-- 匹配信息标题 -->
    <view class="match-info-header">
      <view class="info-icon">
        <image src="/static/match-single-part1/star.png" class="info-star" mode="aspectFit" />
      </view>
      <text class="info-title">为您匹配到的队友信息</text>
    </view>

    <!-- 组队确认 -->
    <view class="team-confirm-section">
      <view class="confirm-header">
        <view class="confirm-icon">
          <image src="/static/match-single-part1/star.png" class="confirm-star" mode="aspectFit" />
        </view>
        <text class="confirm-title">是否组队？</text>
      </view>

      <!-- 确认按钮 -->
      <view class="confirm-buttons">
        <button 
          class="confirm-btn yes-btn" 
          :class="{ 'disabled-btn': !matchResult || !matchResult.id || (!isAlreadyMatched && (!recommendations || recommendations.length === 0)) }"
          :disabled="!matchResult || !matchResult.id || (!isAlreadyMatched && (!recommendations || recommendations.length === 0))"
          @click="handleConfirmTeam">
          <text class="confirm-btn-text">是</text>
        </button>
        <button class="confirm-btn no-btn" @click="handleRejectTeam">
          <text class="confirm-btn-text">否</text>
        </button>
      </view>
    </view>

    <!-- 等待组队弹窗 -->
    <view v-if="showWaitModal" class="wait-modal-mask">
      <view class="wait-modal" :style="{ backgroundImage: 'url(/static/match-single-part2/wait-match.png)' }">
        <text class="wait-text">确认组队中...</text>
      </view>
    </view>

    <!-- 成功弹窗 -->
    <SuccessModal
      :visible="showSuccessModal"
      @update:visible="showSuccessModal = $event"
      @close="handleSuccessClose"
      :type="successType"
      :title="successTitle"
    />

    <!-- 底部导航栏 -->
    <view class="bottom-navigation">
      <!-- 报名-匹配 (选中状态) -->
      <view class="nav-item active" @click="goToMultipleMatch">
        <view class="nav-icon-wrapper">
          <image src="/static/navigation/match-on.png" class="nav-icon" mode="aspectFit" />
        </view>
        <text class="nav-text active">报名-匹配</text>
      </view>
      
      <!-- 打卡 -->
      <view class="nav-item" @click="goToCheckin">
        <view class="nav-icon-wrapper">
          <image src="/static/navigation/checkin-off.png" class="nav-icon" mode="aspectFit" />
        </view>
        <text class="nav-text">打卡</text>
      </view>
      
      <!-- 广场 -->
      <view class="nav-item" @click="goToSquare">
        <view class="nav-icon-wrapper">
          <image src="/static/navigation/square-off.png" class="nav-icon" mode="aspectFit" />
        </view>
        <text class="nav-text">广场</text>
      </view>
      
      <!-- 我的 -->
      <view class="nav-item" @click="goToMine">
        <view class="nav-icon-wrapper">
          <image src="/static/navigation/mine-off.png" class="nav-icon" mode="aspectFit" />
        </view>
        <text class="nav-text">我的</text>
      </view>
    </view>
  </view>
</template>

<script>
import SuccessModal from '../../components/SuccessModal.vue'
import { recommendMatches, confirmMatch, rejectMatch } from '../../services/match'
import { getUserInfo } from '../../services/auth'
import authUtils from '../../utils/auth'

export default {
  components: {
    SuccessModal
  },
  data() {
    return {
      matchResult: {
        id: null,
        name: '',
        gender: '',
        education: '',
        majorCategory: '',
        college: '',
        avatar: ''
      },
      recommendations: [], // 推荐列表
      currentIndex: 0, // 当前显示的推荐索引
      loading: false,
      showSuccessModal: false,
      successType: 'team-success',
      successTitle: '组队成功！',
      showWaitModal: false, // 等待组队弹窗
      isAlreadyMatched: false // 是否已经匹配成功
    }
  },
  onLoad(options) {
    console.log('单人匹配结果页面加载', options)
    
    // 从上一个页面接收匹配结果数据（如果有）
    if (options.matchData) {
      try {
        this.matchResult = JSON.parse(decodeURIComponent(options.matchData))
      } catch (error) {
        console.error('解析匹配数据失败:', error)
      }
    }
    
    // 加载推荐匹配对象
    this.loadRecommendations()
  },
  methods: {
    async loadRecommendations() {
      this.loading = true
      try {
        const result = await recommendMatches({ limit: 10 })
        console.log('推荐结果:', result)
        
        // 处理返回的数据结构：result 可能是 { code, msg, data } 或直接是 data
        const data = result?.data || result
        
        // 检查是否已经匹配成功
        if (data && data.isMatched === true && data.teammates && data.teammates.length > 0) {
          // 已经匹配成功，显示队友信息
          this.isAlreadyMatched = true
          const teammate = data.teammates[0]
          console.log('队友原始数据:', teammate)
          this.matchResult = {
            id: teammate.id,
            name: teammate.username || teammate.name || '未知',
            gender: teammate.gender === 1 ? '男' : (teammate.gender === 2 ? '女' : ''),
            education: this.getEducationFromGrade(teammate.grade),
            majorCategory: teammate.major_category || teammate.majorCategory || '',
            college: teammate.academy?.name || teammate.academy_name || teammate.college || '',
            avatar: teammate.avatar || ''
          }
          this.recommendations = []
          console.log('已匹配成功，显示队友信息:', this.matchResult)
        } else if (data && data.recommendations && data.recommendations.length > 0) {
          // 有推荐对象
          this.isAlreadyMatched = false
          this.recommendations = data.recommendations
          // 显示第一个推荐对象
          this.updateCurrentMatch(0)
        } else {
          // 没有推荐对象，清空推荐列表和匹配结果
          this.isAlreadyMatched = false
          this.recommendations = []
          this.matchResult = {
            id: null,
            name: '暂无匹配对象',
            gender: '',
            education: '',
            majorCategory: '',
            college: '',
            avatar: ''
          }
          uni.showToast({
            title: '暂无推荐对象',
            icon: 'none',
            duration: 2000
          })
        }
      } catch (error) {
        console.error('加载推荐失败:', error)
        
        // 开发阶段：如果是无效URL错误，使用默认数据
        if (error.errMsg?.includes('invalid url') || error.errno === 600009) {
          console.log('开发阶段：API未配置，使用默认数据')
          // 开发阶段仍然允许使用默认数据进行测试
          this.matchResult = {
            id: null,
            name: '张同学',
            gender: '女',
            education: '本科生',
            majorCategory: '工科',
            college: '计算机学院',
            avatar: ''
          }
        } else {
          // 其他错误，清空推荐列表
          this.recommendations = []
          this.matchResult = {
            id: null,
            name: '暂无匹配对象',
            gender: '',
            education: '',
            majorCategory: '',
            college: '',
            avatar: ''
          }
          uni.showToast({
            title: error.message || '加载推荐失败',
            icon: 'none'
          })
        }
      } finally {
        this.loading = false
      }
    },
    updateCurrentMatch(index) {
      if (index >= 0 && index < this.recommendations.length) {
        const rec = this.recommendations[index]
        this.currentIndex = index
        console.log('推荐对象原始数据:', rec)
        // 转换用户数据格式，使用多个备选字段
        this.matchResult = {
          id: rec.id,
          name: rec.username || rec.name || '未知',
          gender: rec.gender === 1 ? '男' : (rec.gender === 2 ? '女' : ''),
          education: this.getEducationFromGrade(rec.grade),
          majorCategory: rec.major_category || rec.majorCategory || '',
          college: rec.academy?.name || rec.academy_name || rec.college || '',
          avatar: rec.avatar || ''
        }
        console.log('更新后的匹配结果:', this.matchResult)
      }
    },
    getEducationFromGrade(grade) {
      if (!grade) return ''
      return grade <= 4 ? '本科生' : (grade <= 6 ? '研究生' : '')
    },
    handleAvatarError(e) {
      console.error('头像加载失败:', e)
      // 头像加载失败时，清空 avatar，显示占位符
      this.matchResult.avatar = ''
    },
    // 返回期望填写界面
    backToExpectation() {
      uni.navigateBack({
        success: () => {
          console.log('返回期望页面成功')
        },
        fail: (err) => {
          console.warn('返回失败，尝试其他方式:', err)
          // 如果无法返回，尝试重定向
          uni.reLaunch({
            url: '/pages/single-match/index',
            success: () => {
              console.log('重定向到期望页面成功')
            },
            fail: (err2) => {
              console.error('跳转期望页面失败:', err2)
              uni.showToast({
                title: '请手动切换到期望页面',
                icon: 'none',
                duration: 2000
              })
            }
          })
        }
      })
    },
    // 处理组队确认
    async handleConfirmTeam() {
      // 检查是否有有效的匹配对象
      if (!this.matchResult || !this.matchResult.id) {
        uni.showToast({
          title: '暂无匹配对象，无法组队',
          icon: 'none',
          duration: 2000
        })
        return
      }
      
      // 如果已经匹配成功，直接跳转到打卡页面
      if (this.isAlreadyMatched) {
        console.log('已经匹配成功，直接跳转到打卡页面')
        uni.switchTab({
          url: '/pages/checkin-detail/index',
          fail: (err) => {
            console.warn('switchTab失败，尝试reLaunch:', err)
            uni.reLaunch({ url: '/pages/checkin-detail/index' })
          }
        })
        return
      }
      
      // 如果推荐列表为空，但 matchResult.id 存在，说明可能是已经匹配成功的情况
      // 这种情况下允许继续操作（已经匹配成功时，推荐列表为空是正常的）
      // 只有在既没有推荐列表，又没有有效匹配对象ID时才提示错误
      if ((!this.recommendations || this.recommendations.length === 0) && !this.matchResult.id) {
        uni.showToast({
          title: '暂无匹配对象，无法组队',
          icon: 'none',
          duration: 2000
        })
        return
      }
      
      // 检查是否是自己和自己组队
      try {
        // 获取当前用户信息
        let currentUserInfo = authUtils.getUserInfo()
        console.log('🔍 当前用户信息（本地）:', currentUserInfo)
        
        // 如果本地存储没有用户ID，尝试从服务器获取
        if (!currentUserInfo || !currentUserInfo.id) {
          try {
            const serverUserInfo = await getUserInfo()
            console.log('🔍 当前用户信息（服务器）:', serverUserInfo)
            if (serverUserInfo) {
              currentUserInfo = serverUserInfo
              authUtils.setUserInfo(serverUserInfo)
            }
          } catch (err) {
            console.warn('获取用户信息失败:', err)
          }
        }
        
        // 检查匹配到的用户ID是否与当前用户ID相同
        const currentUserId = currentUserInfo?.id || uni.getStorageSync('userId')
        const matchUserId = this.matchResult?.id
        
        console.log('🔍 用户ID检查:', {
          currentUserId,
          matchUserId,
          isSame: currentUserId && matchUserId && String(matchUserId) === String(currentUserId)
        })
        
        if (currentUserId && matchUserId && String(matchUserId) === String(currentUserId)) {
          uni.showToast({
            title: '不能和自己组队',
            icon: 'none',
            duration: 2000
          })
          return
        }
        
        // 如果无法获取当前用户ID，也阻止匹配（安全起见）
        if (!currentUserId) {
          console.warn('⚠️ 无法获取当前用户ID，阻止匹配以确保安全')
          uni.showToast({
            title: '无法验证用户信息，请重新登录',
            icon: 'none',
            duration: 2000
          })
          return
        }
      } catch (err) {
        console.error('检查用户ID失败:', err)
        // 如果检查失败，阻止匹配以确保安全
        uni.showToast({
          title: '验证失败，请重试',
          icon: 'none',
          duration: 2000
        })
        return
      }
      
      try {
        // 显示等待弹窗
        this.showWaitModal = true
        
        // 调用确认组队API
        const result = await confirmMatch({ userId: this.matchResult.id })
        console.log('确认组队成功:', result)
        
        // 隐藏等待弹窗
        this.showWaitModal = false
        
        // 显示成功提示
        this.successType = 'team-success'
        this.successTitle = '组队成功！'
        this.showSuccessModal = true
        
        // 不自动跳转，让用户点击弹窗关闭按钮后再跳转
        // 跳转逻辑移到 handleSuccessClose 方法中
        
      } catch (error) {
        // 隐藏等待弹窗
        this.showWaitModal = false
        console.error('组队失败:', error)
        
        // 开发阶段：如果是无效URL错误，需要检查是否有有效的匹配对象ID
        if (error.errMsg?.includes('invalid url') || error.errno === 600009) {
          // 开发阶段：只有在有有效匹配对象ID时才模拟成功
          if (this.matchResult && this.matchResult.id) {
            console.log('开发阶段：API未配置，模拟组队成功')
            this.successType = 'team-success'
            this.successTitle = '组队成功！'
            this.showSuccessModal = true
          } else {
            uni.showToast({
              title: '暂无匹配对象，无法组队',
              icon: 'none',
              duration: 2000
            })
          }
        } else {
          uni.showToast({
            title: error.message || '组队失败，请重试',
            icon: 'none'
          })
        }
      }
    },
    // 处理拒绝组队
    async handleRejectTeam() {
      uni.showModal({
        title: '确认拒绝',
        content: '确定要拒绝与该同学组队吗？',
        success: async (res) => {
          if (res.confirm) {
            try {
              uni.showLoading({ title: '处理中...' })
              
              // 如果有当前匹配对象，调用拒绝接口
              if (this.matchResult.id) {
                try {
                  await rejectMatch()
                } catch (error) {
                  console.error('拒绝匹配失败:', error)
                  // 如果已经匹配失败，继续显示下一个推荐
                }
              }
              
              uni.hideLoading()
              
              // 显示下一个推荐对象，如果没有则返回期望页面
              if (this.currentIndex + 1 < this.recommendations.length) {
                this.updateCurrentMatch(this.currentIndex + 1)
                uni.showToast({
                  title: '已拒绝，显示下一个推荐',
                  icon: 'success'
                })
              } else {
                // 没有更多推荐，提示用户并返回期望页面
                uni.showToast({
                  title: '已拒绝，请重新匹配',
                  icon: 'success',
                  duration: 2000
                })
                // 延迟返回，让用户看到提示
                setTimeout(() => {
                  this.backToExpectation()
                }, 2000)
              }
            } catch (error) {
              uni.hideLoading()
              console.error('拒绝组队失败:', error)
              
              // 开发阶段：如果是无效URL错误，继续流程
              if (error.errMsg?.includes('invalid url') || error.errno === 600009) {
                console.log('开发阶段：API未配置，继续流程')
                if (this.currentIndex + 1 < this.recommendations.length) {
                  this.updateCurrentMatch(this.currentIndex + 1)
                } else {
                  this.backToExpectation()
                }
              } else {
                uni.showToast({
                  title: error.message || '操作失败，请重试',
                  icon: 'none'
                })
              }
            }
          }
        }
      })
    },
    handleSuccessClose() {
      this.showSuccessModal = false
      
      if (this.successType === 'team-success') {
        // 组队成功后跳转到打卡页面
        console.log('组队成功，跳转到打卡页面')
        // 延迟一下，让弹窗关闭动画完成
        setTimeout(() => {
          uni.switchTab({
            url: '/pages/checkin-detail/index',
            fail: (err) => {
              console.warn('switchTab失败，尝试reLaunch:', err)
              uni.reLaunch({ url: '/pages/checkin-detail/index' })
            }
          })
        }, 300)
      }
    },
    goToSignup() {
      // 跳转到报名页面
      uni.reLaunch({
        url: '/pages/signup/index',
        fail: (err) => {
          console.warn('跳转失败:', err)
          uni.showToast({
            title: '跳转失败，请重试',
            icon: 'none'
          })
        }
      })
    },
    goToMultipleMatch() {
      // 跳转到报名页面，而不是多人匹配页面（多人匹配未开放）
      uni.reLaunch({
        url: '/pages/signup/index',
        fail: (err) => {
          console.warn('跳转失败:', err)
          uni.navigateTo({
            url: '/pages/signup/index',
            fail: () => {
              uni.showToast({
                title: '跳转失败，请重试',
                icon: 'none'
              })
            }
          })
        }
      })
    },
    goToCheckin() {
      uni.switchTab({
        url: '/pages/checkin-detail/index',
        fail: (err) => {
          console.warn('跳转失败:', err)
          uni.reLaunch({ url: '/pages/checkin-detail/index' })
        }
      })
    },
    goToSquare() {
      uni.switchTab({
        url: '/pages/square/index',
        fail: (err) => {
          console.warn('跳转失败:', err)
          uni.reLaunch({ url: '/pages/square/index' })
        }
      })
    },
    goToMine() {
      uni.switchTab({
        url: '/pages/mine/index',
        fail: (err) => {
          console.warn('跳转失败:', err)
          uni.reLaunch({ url: '/pages/mine/index' })
        }
      })
    }
  }
}
</script>

<style scoped>
.single-match-result-page {
  width: 750rpx;
  min-height: 1624rpx; /* 对应812px */
  background: linear-gradient(180deg, #F7E7FF 0%, #FFFFFF 100%);
  position: relative;
  margin: 0 auto;
  padding-bottom: 112rpx; /* 为底部导航栏留空间 */
}

/* 结果页面背景图片 */
.result-gradient-bg {
  position: absolute;
  top: -66rpx; /* 往上移动状态栏的高度，使背景与文字对齐 */
  left: 0;
  right: 0;
  height: 312rpx; /* 对应156px */
  background-image: url('/static/match-single-part1/part2-banner-background.png');
  background-size: cover;
  background-position: center top;
  background-repeat: no-repeat;
  z-index: 1;
}

/* 报名/匹配标签切换区域 */
.tab-section {
  position: absolute;
  top: 72rpx; /* 对应36px */
  left: 138rpx; /* 对应69px */
  width: 472rpx; /* 对应236px */
  height: 74rpx; /* 对应37px */
  z-index: 10;
}

.tab-group {
  display: flex;
  height: 100%;
  position: relative;
}

.tab-item {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 74rpx;
  position: relative;
}

.tab-text {
  font-size: 32rpx; /* 对应16px */
  font-weight: 400;
  color: #FFFFFF;
}

.tab-text.active {
  font-weight: 700;
}

.tab-indicator {
  position: absolute;
  bottom: 13rpx;
  left: 50%;
  transform: translateX(-50%);
  width: 120rpx; /* 对应60px */
  height: 36rpx; /* 对应18px */
  background: rgba(255, 255, 255, 0.4);
  border-radius: 180rpx; /* 对应90px */
}

/* 结果页面标签切换区域 */
.result-tab-section {
  position: absolute;
  top: 180rpx; /* 对应90px，下移标签区域 */
  left: 60rpx; /* 对应30px，从左侧开始 */
  right: 60rpx; /* 对应右侧，实现全宽度分布 */
  height: 38rpx; /* 对应19px */
  z-index: 10;
}

.result-tab-group {
  display: flex;
  height: 100%;
  width: 100%;
  justify-content: space-between; /* 使用space-between均匀分布 */
  align-items: center;
  position: relative;
}

.result-tab-item {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 38rpx; /* 对应19px */
  position: relative;
  flex-shrink: 0; /* 防止压缩 */
}

.result-tab-text {
  font-size: 32rpx; /* 对应16px */
  font-weight: 400;
  color: #000000; /* 改为黑色 */
}

.result-tab-text.active {
  font-weight: 700;
  color: #000000; /* 保持黑色，只是加粗 */
}

.result-tab-item.disabled {
  opacity: 0.5;
  pointer-events: none; /* 禁用点击 */
}

.result-tab-indicator {
  position: absolute;
  bottom: -10rpx; /* 调整位置，在文字下方显示 */
  left: 50%;
  transform: translateX(-50%);
  width: 120rpx; /* 对应60px */
  height: 36rpx; /* 对应18px */
  background: rgba(255, 255, 255, 0.4);
  border-radius: 180rpx; /* 对应90px */
}

/* 匹配结果卡片 */
.match-result-card {
  position: absolute;
  top: 486rpx; /* 对应243px */
  left: 50%;
  transform: translateX(-50%);
  width: 622rpx; /* 对应311px */
  height: 614rpx; /* 对应307px */
  background: #FFFFFF;
  border: 4rpx solid #A100FE; /* 对应2px */
  border-radius: 18rpx; /* 对应9px */
  box-sizing: border-box; /* 确保border不会增加总宽度 */
  z-index: 10;
}

/* 头像区域 */
.avatar-section {
  position: absolute;
  top: 300rpx; /* 对应150px */
  left: 50%;
  transform: translateX(-50%);
  width: 236rpx; /* 对应118px */
  height: 236rpx; /* 对应118px */
  z-index: 15; /* 高于信息展示框的z-index(10)，确保头像显示在上层 */
}

.avatar-circle {
  width: 236rpx; /* 对应118px */
  height: 236rpx; /* 对应118px */
  border-radius: 50%;
  background: #E3E4E4;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.avatar-image {
  width: 100%;
  height: 100%;
  border-radius: 50%;
}

.avatar-placeholder {
  font-size: 80rpx;
  color: #9094A6;
}

/* 匹配信息标题 */
.match-info-header {
  position: absolute;
  top: 552rpx; /* 对应276px */
  left: calc(50% - 392rpx/2 - 17rpx); /* 对应 calc(50% - 196px/2 - 8.5px) */
  width: 392rpx; /* 对应196px */
  height: 52rpx; /* 对应26px */
  display: flex;
  align-items: center;
}

.info-icon {
  width: 66rpx; /* 对应33px */
  height: 52rpx; /* 对应26px */
  margin-right: 20rpx;
  display: flex;
  align-items: center;
  justify-content: flex-start;
}

.info-star {
  width: 40rpx;
  height: 40rpx;
}

.info-title {
  font-size: 32rpx; /* 对应16px */
  font-weight: 400;
  color: #000000;
}

/* 队友信息区域 */
.teammate-info {
  display: flex;
  flex-direction: column;
  padding: 120rpx 40rpx 40rpx; /* 顶部留出头像空间 */
  height: 100%;
  box-sizing: border-box;
}

.info-item {
  display: flex;
  align-items: center;
  margin-bottom: 16rpx;
  padding: 8rpx 0;
}

.info-item:last-child {
  margin-bottom: 0;
}

.info-label {
  font-size: 28rpx;
  font-weight: 400;
  color: #666666;
  width: 120rpx;
  flex-shrink: 0;
}

.info-value {
  font-size: 28rpx;
  font-weight: 400;
  color: #000000;
  flex: 1;
}

/* 组队确认区域 */
.team-confirm-section {
  position: absolute;
  top: 1154rpx; /* 对应577px */
  left: 50%;
  transform: translateX(-50%);
  width: 100%;
}

.confirm-header {
  position: absolute;
  top: 0;
  left: calc(50% - 232rpx/2 + 1rpx); /* 对应 calc(50% - 116px/2 + 0.5px) */
  width: 232rpx; /* 对应116px */
  height: 52rpx; /* 对应26px */
  display: flex;
  align-items: center;
  justify-content: center;
}

.confirm-icon {
  width: 66rpx; /* 对应33px */
  height: 52rpx; /* 对应26px */
  margin-right: 20rpx;
  display: flex;
  align-items: center;
  justify-content: flex-start;
}

.confirm-star {
  width: 40rpx;
  height: 40rpx;
}

.confirm-title {
  font-size: 26rpx; /* 对应16px */
  font-weight: 400;
  color: #000000;
}

/* 确认按钮 */
.confirm-buttons {
  position: absolute;
  top: 106rpx; /* 630px - 577px = 53px ≈ 106rpx */
  left: 64rpx; /* 对应32px */
  width: 622rpx; /* 对应311px */
  height: 94rpx; /* 对应47px */
  display: flex;
  gap: 46rpx; /* 按钮间距 */
  justify-content: center;
}

.confirm-btn {
  width: 280rpx; /* 对应140px */
  height: 94rpx; /* 对应47px */
  border-radius: 180rpx; /* 对应90px */
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
}

.confirm-btn::after {
  border: none;
}

.yes-btn {
  background: linear-gradient(90deg, #A100FE 0%, #FDB9E7 100%);
}

.no-btn {
  background: linear-gradient(90deg, #1F2735 0%, #A100FE 48.08%);
  transform: matrix(-1, 0, 0, 1, 0, 0); /* 水平翻转渐变 */
}

.confirm-btn-text {
  font-size: 32rpx; /* 对应16px */
  font-weight: 400;
  color: #FFFFFF;
}

.confirm-btn.disabled-btn {
  opacity: 0.5;
  pointer-events: none;
  background: #CCCCCC !important;
}

/* 等待组队弹窗 */
.wait-modal-mask {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
}

.wait-modal {
  width: 500rpx;
  height: 500rpx;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  border-radius: 18rpx;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  position: relative;
  animation: fadeIn 0.3s ease-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: scale(0.9);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

.wait-text {
  font-size: 32rpx;
  font-weight: 400;
  color: #FFFFFF;
  text-align: center;
  position: absolute;
  bottom: 80rpx; /* 文字显示在图片底部 */
  left: 50%;
  transform: translateX(-50%);
  z-index: 1;
  text-shadow: 0 2rpx 4rpx rgba(0, 0, 0, 0.3); /* 添加文字阴影以提高可读性 */
}

/* 底部导航栏 */
.bottom-navigation {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 112rpx; /* 对应56px */
  background: #FFFFFF;
  display: flex;
  align-items: center;
  justify-content: space-around;
  padding: 0;
  z-index: 100;
  box-shadow: 0 -2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 112rpx; /* 对应56px */
  height: 112rpx;
  cursor: pointer;
}

.nav-icon-wrapper {
  width: 56rpx; /* 对应28px */
  height: 56rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 8rpx;
}

.nav-icon {
  width: 48rpx; /* 对应24px */
  height: 48rpx;
}

.nav-text {
  font-size: 20rpx; /* 对应10px */
  color: #9094A6;
  font-weight: 400;
  text-align: center;
  line-height: 24rpx; /* 对应12px */
}

.nav-text.active {
  color: #1F2635;
  font-weight: 400;
}

/* 为"报名-匹配"选中状态特殊处理 */
.nav-item.active .nav-text {
  color: #1F2635;
}
</style>
