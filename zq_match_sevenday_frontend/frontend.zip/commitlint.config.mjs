export default {
  extends: ['@zqstudio/configs/commitlint'],
};
